import services.impl.SnakeLadderGameplay;

public class Main {
  public static void main(String[] args) {
    SnakeLadderGameplay game = new SnakeLadderGameplay("Faizan", "Asif");
    game.playGame();
  }
}
