package services;

public interface Gameplay {
  void playGame();
}
